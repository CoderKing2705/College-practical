export interface IUser{
    userId:number;
    userName:string;
    email:string;
    phone:string;
    password:string;
}