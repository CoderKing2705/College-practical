export interface IAddress{
    addressId:number;
    userId : number;
    contactNo:string;
    contactPerson:string;
    pinCode:number;
    city:string;
    state:string;
    country:string;
    address:string;
    addressType:string;

}