import { IProduct } from "./IProduct";

export interface ICreateOrder{  
    email:string;
    productList:any;
    addressId:any;
}