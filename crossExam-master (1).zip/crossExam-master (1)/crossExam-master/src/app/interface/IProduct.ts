export interface IProduct{
    productid:number;
    name:string;
    description:string;
    price:number;
    quantity:number;
    isactive:boolean;
    createdon:string;
    modifiedon:string;
}