﻿using Microsoft.AspNetCore.Mvc;
using TaskLetanus.Data;
using TaskLetanus.Models;

namespace TaskLetanus.Controllers
{
    public class EmployeesController : Controller
    {
        private readonly ApplicationDbContext _db;

        public EmployeesController(ApplicationDbContext db)
        {
            _db = db;
        }

        public IActionResult Index()
        {
            List<Employees> employeesList = _db.Employees.ToList();
            return View(employeesList);
        }

        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Create(Employees emp)
        {
            _db.Employees.Add(emp);
            _db.SaveChanges();
            return RedirectToAction("Index");
        }

        public IActionResult Edit(int? id)
        {
            if (id == null || id == 0)
            {
                return NotFound();
            }
            Employees? empData = _db.Employees.Find(id);
            if (empData == null)
            {
                return NotFound();
            }
            return View(empData);
        }

        [HttpPost]
        public IActionResult Edit(Employees empData)
        {
            if (ModelState.IsValid)
            {
                _db.Employees.Update(empData);
                _db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View();
        }

        public IActionResult Delete(int? id)
        {
            if (id == null || id == 0)
            {
                return NotFound();
            }
            Employees? empData = _db.Employees.Find(id);
            if (empData == null)
            {
                return NotFound();
            }
            return View(empData);
        }

        [HttpPost, ActionName("Delete")]
        public IActionResult DeletePost(int? id)
        {
            Employees? obj = _db.Employees.Find(id);
            if (obj == null)
            {
                return NotFound();
            }
            _db.Employees.Remove(obj);
            _db.SaveChanges();
            return RedirectToAction("Index");

        }
    }
}
