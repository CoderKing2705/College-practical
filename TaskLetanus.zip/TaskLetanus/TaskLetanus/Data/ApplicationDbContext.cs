﻿using Microsoft.EntityFrameworkCore;
using TaskLetanus.Models;

namespace TaskLetanus.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
        {
            
        }

        public DbSet<Employees> Employees { get; set; }
    }
}
