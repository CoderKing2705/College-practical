﻿using System.ComponentModel.DataAnnotations;

namespace TaskLetanus.Models
{
    public class Employees
    {
        [Key]
        public int Id { get; set; }

        [MaxLength(200)]
        [Required]
        public string FirstName { get; set; }

        [Required]
        [MaxLength(200)]
        public string LastName { get; set; }

        public Gender Gender { get; set; }

        [Required]
        public City City { get; set; }
    }

    public enum Gender
    {
        Male,
        Female
    }
    public enum City
    {
        Ahmedabad,
        Gandhinagar,
        Surat
    }
}
